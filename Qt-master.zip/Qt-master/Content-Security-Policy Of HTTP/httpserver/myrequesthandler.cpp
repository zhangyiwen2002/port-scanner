﻿#include "myrequesthandler.h"

MyRequestHandler::MyRequestHandler(QObject *parent)
{

}
