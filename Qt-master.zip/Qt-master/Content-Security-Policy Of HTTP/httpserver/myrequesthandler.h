﻿#ifndef MYREQUESTHANDLER_H
#define MYREQUESTHANDLER_H


class MyRequestHandler
{
public:
    MyRequestHandler();
};

#endif // MYREQUESTHANDLER_H
