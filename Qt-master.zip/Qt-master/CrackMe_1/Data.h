#ifndef DATA_H
#define DATA_H

static int resource = 10;

#endif // DATA_H
