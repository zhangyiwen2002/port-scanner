﻿function showPic(item) {

    item.anchors.leftMargin = item.anchors.leftMargin + 1
}

function hidePic(item) {

    item.anchors.leftMargin = item.anchors.leftMargin - 1
}
