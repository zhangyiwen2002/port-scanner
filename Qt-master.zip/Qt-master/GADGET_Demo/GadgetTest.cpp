#include "GadgetTest.h"

GadgetTest::GadgetTest()
{

}
