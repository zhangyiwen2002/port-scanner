﻿#include "component.h"


void Component::processOperation(QWidget *page)
{
    Q_UNUSED(page)
}

Component::Component()
{

}
