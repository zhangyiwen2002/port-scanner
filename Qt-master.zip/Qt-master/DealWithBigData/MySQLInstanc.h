#ifndef MYSQLINSTANC_H
#define MYSQLINSTANC_H


class MySQLInstance
{
public:
    MySQLInstance();

};

#endif // MYSQLINSTANC_H
