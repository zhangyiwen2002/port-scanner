#include "MySQLInstanc.h"

MySQLInstance::MySQLInstance(QObject *parent) : QObject(parent)
{

}
