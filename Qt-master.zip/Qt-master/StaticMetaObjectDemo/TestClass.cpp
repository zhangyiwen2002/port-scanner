#include "TestClass.h"

TestClass::TestClass(QObject *parent) : QObject(parent)
{

}
