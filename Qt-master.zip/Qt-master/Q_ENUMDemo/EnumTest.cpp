#include "EnumTest.h"

EnumTest::EnumTest(QObject *parent) : QObject(parent)
{

}
